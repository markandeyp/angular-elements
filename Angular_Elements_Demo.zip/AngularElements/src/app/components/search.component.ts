import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'ui-search',
  template: `<input
      type="text"
      [placeholder]="placeholder"
      [(ngModel)]="searchTerm"
    /><button (click)="doSearch()">Search</button>`,
})
export class SearchComponent {
  @Input()
  searchTerm: string = '';

  @Input()
  placeholder: string = 'Search';

  @Output()
  search = new EventEmitter<string>();

  @Output()
  change = new EventEmitter<string>();

  doSearch() {
    console.log(`Searching for ${this.searchTerm}`);
    this.search.next(this.searchTerm);
  }
}
