import { Injector, NgModule } from '@angular/core';
import { createCustomElement } from '@angular/elements';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';

import { SearchComponent } from './components/search.component';

@NgModule({
  declarations: [SearchComponent],
  imports: [BrowserModule, FormsModule],
  providers: [],
  bootstrap: [], //Remove bootstrap elements as we are not using these components inside this library
})
export class AppModule {
  constructor(private injector: Injector) {}

  //Create web components from our Angular components and register them
  ngDoBootstrap() {
    const SearchElement = createCustomElement(SearchComponent, {
      injector: this.injector,
    });
    customElements.define('wc-ui-search', SearchElement); //register a web component
  }
}
